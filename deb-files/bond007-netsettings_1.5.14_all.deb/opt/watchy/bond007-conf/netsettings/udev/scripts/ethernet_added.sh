#!/bin/bash
DONGLE_NUMBER=$1

echo `date +%d-%m-%Y-%H:%M:%S`" | dongle"$DONGLE_NUMBER" | ETHERNET ADDED " >> /var/log/watchy/dongle_manager.udev

MSG="{\"action\":\"ETHERNET_ADDED\"}"
echo $MSG | nc -CU /tmp/watchy/dongle"$DONGLE_NUMBER".sock
