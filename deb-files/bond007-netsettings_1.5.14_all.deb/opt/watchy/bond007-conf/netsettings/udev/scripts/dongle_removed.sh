#!/bin/bash

DONGLE_NUMBER=$1

echo `date +%d-%m-%Y-%H:%M:%S`" | dongle"$DONGLE_NUMBER" | DONGLE REMOVED " >> /var/log/watchy/dongle_manager.udev

MSG="{\"action\":\"DONGLE_REMOVED\"}"
echo $MSG | nc -CU /tmp/watchy/dongle"$DONGLE_NUMBER".sock

