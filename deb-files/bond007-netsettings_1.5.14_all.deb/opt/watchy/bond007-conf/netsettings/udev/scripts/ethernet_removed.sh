#!/bin/bash
DONGLE_NUMBER=$1

echo `date +%d-%m-%Y-%H:%M:%S`" | dongle"$DONGLE_NUMBER" | ETHERNET REMOVED " >> /var/log/watchy/dongle_manager.udev

MSG="{\"action\":\"ETHERNET_REMOVED\"}"
echo $MSG | nc -CU /tmp/watchy/dongle"$DONGLE_NUMBER".sock
